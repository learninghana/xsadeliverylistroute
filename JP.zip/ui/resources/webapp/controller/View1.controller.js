var controller;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, MessageToast, MessageBox, JSONModel) {
	"use strict";

	return Controller.extend("display.ui.controller.View1", {
		onInit: function() {
			controller = this;
			var oModel = new sap.ui.model.odata.ODataModel("odata/services/products.xsodata", true);
			var sPath = "/TodaysDelParameters(ip_lat=" + "'" + -37.929822 + "'" + ",ip_long=" + "'" + "145.118949" + "'" +
				")/Results?$orderby=Distance";

			oModel.read(sPath, {
					success: function(oData, Param) {
						var oODataJSONModel = new sap.ui.model.json.JSONModel();
						oODataJSONModel.setData(oData);
						var oView = controller.getView();
						// oView.setModel(oODataJSONModel);
					},
					error: function(oError) {
						var dfg = 9;
					}
				}

			);
			var jModel = new sap.ui.model.json.JSONModel('test/test.xsjs?ip_lat=-37.929822&ip_long=145.118949');
			jModel.attachRequestCompleted(function() {
				jModel.getJSON();
				var oView = controller.getView();
				oView.setModel(jModel);
			});
			// jModel.loadData('test/test.xsjs', 'ip_lat=-37.929822&ip_long=145.118949');
			// $.ajax({
			// 	type: 'GET',
			// 	url: '/test/test.xsjs?ip_lat=-37.929822&ip_long=145.118949',
			// 	dataType: 'json',
			// 	success: function(data, textStatus, jqXHR) {
			// 		console.log(data);

			// 	},
			// 	error: function(jqXHR, textStatus, errorThrown) {

			// 	}
			// });
			var oView = controller.getView();
			oView.setModel(jModel, 'test');
			// this.oSF1 = oView.byId("searchField");
			// this.oSF2 = oView.byId("searchField1");

			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;
			// keeps the search state
			this._aTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: 'Products', //this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: '', //this.getResourceBundle().getText("worklistTitle"),
				// shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				// shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				// tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				inStock: 0,
				shortage: 0,
				outOfStock: 0,
				countAll: 0
			});
			// oView.setModel(oViewModel, "worklistView");
			// this._mFilters = {
			// 	"inStock": [new Filter("UnitsInStock", "GT", 10)],
			// 	"outOfStock": [new Filter("UnitsInStock", "LE", 0)],
			// 	"shortage": [new Filter("UnitsInStock", "BT", 1, 10)],
			// 	"all": []
			// };

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});

			// sap.ui.getCore().loadLibrary("openui5.googlemaps", "../openui5/googlemaps/");
		},

		onAfterRendering: function() {
			// this.loadGoogleMaps("https://maps.googleapis.com/maps/api/js?key=AIzaSyCiZNyjfAv-gRYK9TuZQQFk3zb6VoBg3J0", me.setMapData.bind(me));
		},

		loadGoogleMaps: function(scriptUrl, callbackFn) {
			var script = document.createElement("script");
			script.onload = function() {
				callbackFn();
			};
			script.src = scriptUrl;
			document.body.appendChild(script);
		},

		// function to set map data
		setMapData: function() {
			// var myCenter = new google.maps.LatLng(-25.344358, 131.036867);
			// var mapProp = {
			// 	center: myCenter,
			// 	zoom: 4,
			// 	scrollwheel: true,
			// 	draggable: true
			// };
			// new google.maps.Map(this.getView().byId("gmaps1").getDomRef(), mapProp);
		},

		showStores: function(oCenterLoc, aStoreLoc) {

			// var centerSuburb = new google.maps.LatLng(
			// 	parseFloat(oCenterLoc.centerLat),
			// 	parseFloat(oCenterLoc.centerLng)
			// );
			// var properties = {
			// 	center: centerSuburb,
			// 	zoom: 13,
			// 	draggable: true
			// };
			// var map = new google.maps.Map(this.getView().byId("gmaps1").getDomRef(), properties);

			// for (var i = 0; i < aStoreLoc.results.length; i++) {
			// 	var storeMarkerLoc = new google.maps.LatLng(
			// 		parseFloat(aStoreLoc.results[i].latitude),
			// 		parseFloat(aStoreLoc.results[i].logitude)
			// 	);
			// 	var marker = new google.maps.Marker({
			// 		position: storeMarkerLoc,
			// 		animation: google.maps.Animation.DROP,
			// 		map: map
			// 	});
			// }

		},

		// onSearch: function(event) {
		// var me = this;
		// var oSource = event.getSource();
		// oSource.suggest(false);
		// var oCenterLoc = {};
		// var item = event.getParameter("suggestionItem");
		// if (item) {
		// 	var sPath = "/LocRepo('" + item.getKey() + "')";
		// 	var oModel = this.getView().getModel();
		// 	oModel.read(sPath, {
		// 		success: function(oData, oResponse) {
		// 			oCenterLoc.centerLng = oData.longitude;
		// 			oCenterLoc.centerLat = oData.latitude;
		// 			sap.m.MessageToast.show("Nearest stores to " + oData.locality + " marked on map");
		// 			var sStoreLocPath = "/StoreLocationParameters(in_longitude='" + oData.longitude + "',in_latitude='" + oData.latitude +
		// 				"')/Results?$orderby=distance&$top=5";
		// 			oModel.read(sStoreLocPath, {
		// 				success: function(oData, oResponse) {
		// 					me.showStores(oCenterLoc, oData);
		// 				},
		// 				error: function(oError) {
		// 					sap.m.MessageToast.show("Error fetching stores" + oError);
		// 				}
		// 			});
		// 		},
		// 		error: function(oError) {
		// 			sap.m.MessageToast.show("Error fetching coordinates" + oError);
		// 		}
		// 	});
		// }
		// },

		onSuggest1: function(event) {
			var oSF1 = this.oSF1;
			var value = event.getParameter("suggestValue");
			var filters = [];
			if (value) {
				var filter = new sap.ui.model.Filter("prod_description", sap.ui.model.FilterOperator.StartsWith, value);
				filters.push(filter);

				var oBinding = this.oSF1.getBinding("suggestionItems");
				oBinding.filter(filters);
				oBinding.attachEventOnce("dataReceived", function() {
					oSF1.suggest();
				});
			}
		},
		onSuggest2: function(event) {
			var oSF2 = this.oSF2;
			var value = event.getParameter("suggestValue");
			var filters = [];
			if (value) {
				var filter = new sap.ui.model.Filter("prod_description", sap.ui.model.FilterOperator.StartsWith, value);
				filters.push(filter);

				var oBinding = this.oSF2.getBinding("suggestionItems");
				oBinding.filter(filters);
				oBinding.attachEventOnce("dataReceived", function() {
					oSF2.suggest();
				});
			}
		},
		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				// oViewModel = this.getView().getModel("worklistView"),
				oViewModel = this.getView().getModel("worklistView"),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			// if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
			// 	// sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			// 	// Get the count for all the products and set the value to 'countAll' property
			// 	this.getView().getModel().read("/Products/$count", {
			// 		success: function(oData) {
			// 			oViewModel.setProperty("/countAll", oData);
			// 		}
			// 	});
			// read the count for the unitsInStock filter
			// this.getView().getModel().read("/Products/$count", {
			// 	success: function(oData) {
			// 		oViewModel.setProperty("/inStock", oData);
			// 	},
			// 	filters: this._mFilters.inStock
			// });
			// // read the count for the outOfStock filter
			// this.getModel().read("/Products/$count", {
			// 	success: function(oData) {
			// 		oViewModel.setProperty("/outOfStock", oData);
			// 	},
			// 	filters: this._mFilters.outOfStock
			// });
			// // read the count for the shortage filter
			// this.getModel().read("/Products/$count", {
			// 	success: function(oData) {
			// 		oViewModel.setProperty("/shortage", oData);
			// 	},
			// 	filters: this._mFilters.shortage
			// });
			// } else {
			// 	sTitle = this.getResourceBundle().getText("worklistTableTitle");
			// }
			// this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser history
		 * @public
		 */
		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("ProductName", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getOwnerComponent().getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("product")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		// _applySearch: function(aTableSearchState) {
		// 	var oTable = this.byId("table"),
		// 		oViewModel = this.getModel("worklistView");
		// 	oTable.getBinding("items").filter(aTableSearchState, "Application");
		// 	// changes the noDataText of the list in case there are no filter results
		// 	if (aTableSearchState.length !== 0) {
		// 		oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
		// 	}
		// },

		/**
		 * Displays an error message dialog. The displayed dialog is content density aware.
		 * @param {string} sMsg The error message to be displayed
		 * @private
		 */
		_showErrorMessage: function(sMsg) {
			MessageBox.error(sMsg, {
				styleClass: this.getOwnerComponent().getContentDensityClass()
			});
		},

		/**
		 * Event handler when a filter tab gets pressed
		 * @param {sap.ui.base.Event} oEvent the filter tab event
		 * @public
		 */
		onQuickFilter: function(oEvent) {
			var oBinding = this._oTable.getBinding("items"),
				sKey = oEvent.getParameter("selectedKey");
			oBinding.filter(this._mFilters[sKey]);
		},

		/**
		 * Error and success handler for the unlist action.
		 * @param {string} sProductId the product ID for which this handler is called
		 * @param {boolean} bSuccess true in case of a success handler, else false (for error handler)
		 * @param {number} iRequestNumber the counter which specifies the position of this request
		 * @param {number} iTotalRequests the number of all requests sent
		 * @private
		 */

		_handleUnlistActionResult: function(sProductId, bSuccess, iRequestNumber, iTotalRequests) {
			// we could create a counter for successful and one for failed requests
			// however, we just assume that every single request was successful and display a success message once
			if (iRequestNumber === iTotalRequests) {
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("StockRemovedSuccessMsg", [iTotalRequests]));
			}
		},

		/**
		 * Error and success handler for the reorder action.
		 * @param {string} sProductId the product ID for which this handler is called
		 * @param {boolean} bSuccess true in case of a success handler, else false (for error handler)
		 * @param {number} iRequestNumber the counter which specifies the position of this request
		 * @param {number} iTotalRequests the number of all requests sent
		 * @private
		 */

		_handleReorderActionResult: function(sProductId, bSuccess, iRequestNumber, iTotalRequests) {
			// we could create a counter for successful and one for failed requests
			// however, we just assume that every single request was successful and display a success message once
			if (iRequestNumber === iTotalRequests) {
				MessageToast.show(this.getModel("i18n").getResourceBundle().getText("StockUpdatedSuccessMsg", [iTotalRequests]));
			}
		},

		/**
		 * Event handler for the unlist button. Will delete the
		 * product from the (local) model.
		 * @public
		 */

		onUnlistObjects: function() {
			var aSelectedProducts, i, sPath, oProduct, oProductId;

			aSelectedProducts = this.byId("table").getSelectedItems();
			if (aSelectedProducts.length) {
				for (i = 0; i < aSelectedProducts.length; i++) {
					oProduct = aSelectedProducts[i];
					oProductId = oProduct.getBindingContext().getProperty("ProductID");
					sPath = oProduct.getBindingContext().getPath();
					this.getView().getModel().update(sPath, {
						success: this._handleUnlistActionResult.bind(this, oProductId, true, i + 1, aSelectedProducts.length),
						error: this._handleUnlistActionResult.bind(this, oProductId, false, i + 1, aSelectedProducts.length)
					});
				}
			} else {
				this._showErrorMessage(this.getModel("i18n").getResourceBundle().getText("TableSelectProduct"));
			}
		},

		/**
		 * Event handler for the reorder button. Will reorder the
		 * product by updating the (local) model
		 * @public
		 */

		onUpdateStockObjects: function() {
			var aSelectedProducts, i, sPath, oProductObject;

			aSelectedProducts = this.byId("table").getSelectedItems();
			if (aSelectedProducts.length) {
				for (i = 0; i < aSelectedProducts.length; i++) {
					// sPath = aSelectedProducts[i].getBindingContext().getPath();
					oProductObject = aSelectedProducts[i].getBindingContext().getObject();
					oProductObject.DelvStatus = "Completed";
					var oData = {
						OrderNo: oProductObject.OrderNo,
						DeliveryAddress: oProductObject.DeliveryAddress,
						HighRisk: oProductObject.HighRisk,
						DelvStatus: oProductObject.DelvStatus,
						DateofDelivery: oProductObject.DateofDelivery,
						lat_del_adr: oProductObject.lat_del_adr,
						long_del_adr: oProductObject.long_del_adr
					};
					var oModel = new sap.ui.model.odata.ODataModel("odata/services/products.xsodata", true);
					sPath = "/Delivery('" + oProductObject.OrderNo + "')";
					var controller = this;
					oModel.update(sPath, oData, {
						// success: this._handleReorderActionResult.bind(this, oProductObject.ProductID, true, i + 1, aSelectedProducts.length),
						// error: this._handleReorderActionResult.bind(this, oProductObject.ProductID, false, i + 1, aSelectedProducts.length)
						success: function(oData, Param) {
							// var sPath = "/TodaysDelParameters(ip_lat=" + "'" + -37.929822 + "'" + ",ip_long=" + "'" + "145.118949" + "'" +
							// 	")/Results?$orderby=Distance";
							// oModel.read(sPath, {
							// 	success: function(oData, Param) {
							// 		var oODataJSONModel = new sap.ui.model.json.JSONModel();
							// 		oODataJSONModel.setData(oData);
							// 		var oView = controller.getView();
							// 		oView.setModel(oODataJSONModel);
							var jModel = new sap.ui.model.json.JSONModel('test/test.xsjs?ip_lat=-37.929822&ip_long=145.118949');
							jModel.attachRequestCompleted(function() {
								jModel.getJSON();
								var oView = controller.getView();
								oView.setModel(jModel);
							});
							// },
							// error: function(oError) {
							// 	var dfg = 9;
							// }
							// });
						},
						error: this.myerrorHandler
					});
				}
			} else {
				this._showErrorMessage(this.getModel("i18n").getResourceBundle().getText("TableSelectProduct"));
			}
		},
		myerrorHandler: function() {
			var abc = 1;

		}
	});
});